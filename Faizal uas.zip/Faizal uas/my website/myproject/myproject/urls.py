from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('index.html', views.Home),
    path('about.html', views.about),
    path('guard.html', views.guard),
    path('service.html', views.service),
    path('contact.html', views.contact),
    
]
    
    
